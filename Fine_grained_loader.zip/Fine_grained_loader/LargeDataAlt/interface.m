
setBackingRegime;

releasePart;

savedOnDisk;

removePartOnDisk;

savePartOnDisk;

setPartDefined;

setPart;

releaseAPI;

appendTo;

appendList;

removeStorage;

releaseAllMemory;

deleteListComplete;

initList;

storeMainList;

retrieveMainList;

ElementSizeLimit;

DestinationDirectory;