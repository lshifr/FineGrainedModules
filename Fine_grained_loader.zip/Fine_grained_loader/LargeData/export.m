

export = 
   Function[{fname, compressedValue}, 
      Export[fname, compressedValue, "String"]];