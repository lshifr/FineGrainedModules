

import =  
   Function[fname, Import[fname, "String"]];