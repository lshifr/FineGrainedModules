export@{	
	ListFileName	
}


ClearAll[getMainListFileName];
Options[getMainListFileName] = {
   DestinationDirectory :> $destinationDirectory,
   ListFileName -> Automatic
 };
getMainListFileName[s_Symbol, opts : OptionsPattern[]] :=
  LetL[{fn = OptionValue[ListFileName],
    fname = If[fn === Automatic, ToString[s] <> ".m", fn],
    fullfname = FileNameJoin[{OptionValue[ DestinationDirectory], fname}]},
   fullfname];