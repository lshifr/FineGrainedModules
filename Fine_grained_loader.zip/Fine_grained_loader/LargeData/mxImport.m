

mxImport = 
   Function[fname, Block[{data}, Get[fname]; data]];